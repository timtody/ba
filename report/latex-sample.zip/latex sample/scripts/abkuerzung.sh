#!/bin/bash
# runme if you want to update all your abbreviations
makeindex ../src/Hauptdatei.nlo -s ../src/latex_einstellungen/abkuezungen/nomencl.ist -o ../src/Hauptdatei.nls